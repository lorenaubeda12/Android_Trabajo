package com.trabajo_vinted_lorenablasco.trabajo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoLorenaBlascoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoLorenaBlascoApplication.class, args);
	}

}
