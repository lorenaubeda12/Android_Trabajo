package com.trabajo_vinted_lorenablasco.trabajo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoLorenaBlascoApplicationTests {

	@Test
	void contextLoads() {
	}

}
